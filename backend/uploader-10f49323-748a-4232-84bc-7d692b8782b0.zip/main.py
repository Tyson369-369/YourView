import os
import uuid
import hashlib
from typing import Optional

import boto3
from botocore.config import Config

from fastapi import FastAPI, File, UploadFile, HTTPException, Form, Body
from fastapi.middleware.cors import CORSMiddleware
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from mangum import Mangum

# =========================
# Env & constants
# =========================
AWS_REGION = os.getenv("AWS_REGION", "ap-southeast-2")
S3_BUCKET = os.getenv("S3_BUCKET")
MAX_FILE_SIZE = int(os.getenv("MAX_FILE_SIZE", 60 * 1024 * 1024))  # Default 60 MB

DDB_TABLE = os.getenv("DDB_TABLE")  # e.g. img_hash_index

# Sightengine credentials (must be set in Lambda env)
SIGHTENGINE_USER = os.getenv("SIGHTENGINE_USER")
SIGHTENGINE_SECRET = os.getenv("SIGHTENGINE_SECRET")

# Optional: restrict delete to a safe prefix (defense-in-depth)
ALLOWED_DELETE_PREFIXES = [p.strip() for p in os.getenv(
    "ALLOWED_DELETE_PREFIXES",
    "YourWindow/,PlantHealth/"
).split(",") if p.strip()]

if not S3_BUCKET:
    raise RuntimeError("Missing S3_BUCKET env var")
if not SIGHTENGINE_USER or not SIGHTENGINE_SECRET:
    raise RuntimeError("Missing Sightengine credentials (SIGHTENGINE_USER / SIGHTENGINE_SECRET)")

# =========================
# AWS clients
# =========================
s3 = boto3.client(
    "s3",
    region_name=AWS_REGION,
    config=Config(s3={"addressing_style": "virtual"})
)

# >>> DDB
ddb = None
if DDB_TABLE:
    ddb = boto3.client("dynamodb", region_name=AWS_REGION)

# =========================
# FastAPI app
# NOTE: root_path='/default' because your API Gateway stage is 'default'
# =========================
app = FastAPI(title="Image Uploader to S3 (with Moderation + De-dup)", version="1.3.0", root_path="/default")

# CORS (tighten in production: set to your exact frontend origin)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =========================
# Allow only JPEG and PNG (checked via magic bytes, not by filename)
# =========================
ALLOWED_CONTENT_TYPES = {
    "image/jpeg": ".jpg",
    "image/png":  ".png",
}

# =========================
# Sightengine tuning
# =========================
NUDITY_THRESHOLDS = {
    "sexual_activity": 0.50,
    "sexual_display": 0.50,
    "erotica": 0.80,
}

SIGHTENGINE_CONNECT_TIMEOUT = float(os.getenv("SIGHTENGINE_CONNECT_TIMEOUT", "8"))
SIGHTENGINE_READ_TIMEOUT    = float(os.getenv("SIGHTENGINE_READ_TIMEOUT", "45"))
SIGHTENGINE_TOTAL_RETRIES   = int(os.getenv("SIGHTENGINE_TOTAL_RETRIES", "3"))
SIGHTENGINE_BACKOFF_FACTOR  = float(os.getenv("SIGHTENGINE_BACKOFF_FACTOR", "0.6"))

def _requests_session_with_retries() -> requests.Session:
    retry = Retry(
        total=SIGHTENGINE_TOTAL_RETRIES,
        backoff_factor=SIGHTENGINE_BACKOFF_FACTOR,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset(["POST"]),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    s = requests.Session()
    s.mount("https://", adapter)
    s.mount("http://", adapter)
    return s

def detect_image_type(data: bytes) -> Optional[str]:
    if len(data) >= 3 and data[0:3] == b"\xFF\xD8\xFF":
        return "image/jpeg"
    if len(data) >= 8 and data[0:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    return None

def check_image_with_sightengine(bytes_data: bytes, filename: str, content_type: str) -> None:
    url = "https://api.sightengine.com/1.0/check.json"
    files = {"media": (filename or "upload", bytes_data, content_type or "application/octet-stream")}
    data = {"models": "nudity-2.1", "api_user": SIGHTENGINE_USER, "api_secret": SIGHTENGINE_SECRET}

    session = _requests_session_with_retries()
    try:
        resp = session.post(url, files=files, data=data, timeout=(SIGHTENGINE_CONNECT_TIMEOUT, SIGHTENGINE_READ_TIMEOUT))
    except requests.Timeout as e:
        raise HTTPException(status_code=504, detail=f"Moderation timeout: {e}")
    except requests.RequestException as e:
        raise HTTPException(status_code=502, detail=f"Moderation service unavailable: {e}")

    # Parse JSON response
    try:
        result = resp.json()
    except ValueError:
        raise HTTPException(status_code=502, detail="Moderation service returned invalid JSON")

    if resp.status_code != 200:
        err = (result.get("error", {}) or {}).get("message") if isinstance(result, dict) else None
        raise HTTPException(status_code=502, detail=f"Moderation service error: {err or 'unknown'}")

    nudity = (result or {}).get("nudity", {})
    if not isinstance(nudity, dict) or not nudity:
        raise HTTPException(status_code=400, detail="Upload rejected: content analysis failed")

    for label, threshold in NUDITY_THRESHOLDS.items():
        score = float(nudity.get(label, 0.0))
        if score >= threshold:
            raise HTTPException(status_code=400, detail="Upload rejected: image contains disallowed content")

# =========================
# Helpers: canonical key & DDB
# =========================

def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def build_canonical_key(folder: str, ext: str, sha256: str) -> str:
    safe_folder = (folder or "").strip().lstrip("/")
    if safe_folder and not safe_folder.endswith("/"):
        safe_folder += "/"
    # >>> <folder>/<sha256>.<ext>
    return f"{safe_folder}{sha256}{ext}"

def ddb_get_key_by_hash(h: str) -> Optional[str]:
    if not ddb:
        return None
    try:
        resp = ddb.get_item(
            TableName=DDB_TABLE,
            Key={"hash": {"S": h}},
            ConsistentRead=True
        )
        item = resp.get("Item")
        if item and "key" in item:
            return item["key"]["S"]
        return None
    except Exception:
        return None

def ddb_put_hash_mapping(h: str, key: str, size: int, content_type: str) -> None:
    if not ddb:
        return
    try:
        ddb.put_item(
            TableName=DDB_TABLE,
            Item={
                "hash": {"S": h},
                "key": {"S": key},
                "size": {"N": str(size)},
                "contentType": {"S": content_type},
            },
            ConditionExpression="attribute_not_exists(hash)"
        )
    except Exception:
        pass

def s3_object_exists(bucket: str, key: str) -> bool:
    try:
        s3.head_object(Bucket=bucket, Key=key)
        return True
    except Exception:
        return False

# =========================
# Healthcheck
# =========================
@app.get("/health")
def health():
    return {"ok": True}

# =========================
# Upload endpoint (with de-dup)
# =========================
@app.post("/upload-image")
async def upload_image(
    file: UploadFile = File(..., description="multipart/form-data field name = file"),
    folder: Optional[str] = Form(default="YourWindow", description="Optional S3 subfolder, e.g., 'uploads/'")
):
    # 1) Read file into memory (size limit)
    contents = await file.read()
    if len(contents) == 0:
        raise HTTPException(status_code=400, detail="Empty file")
    if len(contents) > MAX_FILE_SIZE:
        raise HTTPException(status_code=413, detail=f"File too large (> {MAX_FILE_SIZE} bytes)")

    # 2) Enforce JPEG/PNG using magic bytes
    detected_ct = detect_image_type(contents)
    if detected_ct not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(status_code=400, detail="Only JPG and PNG are allowed")
    ext = ALLOWED_CONTENT_TYPES[detected_ct]

    # 3) Moderation
    check_image_with_sightengine(contents, file.filename or "upload", detected_ct)

    # 4) Compute strong hash & build canonical key
    h = sha256_hex(contents)
    canonical_key = build_canonical_key(folder or "YourWindow", ext, h)

    # 5) Global de-dup check
    existing_key = ddb_get_key_by_hash(h) if ddb else (canonical_key if s3_object_exists(S3_BUCKET, canonical_key) else None)
    if existing_key:
        presigned_url = None
        try:
            presigned_url = s3.generate_presigned_url(
                "get_object",
                Params={"Bucket": S3_BUCKET, "Key": existing_key},
                ExpiresIn=3600
            )
        except Exception:
            pass

        return {
            "bucket": S3_BUCKET,
            "key": existing_key,
            "content_type": detected_ct,
            "size": len(contents),
            "duplicate": True,
            "canonical": True,
            "canonicalKey": existing_key,
            "presigned_url": presigned_url,
            "moderation": "passed",
        }

    # 6) canonical key
    try:
        put_resp = s3.put_object(
            Bucket=S3_BUCKET,
            Key=canonical_key,
            Body=contents,
            ContentType=detected_ct,
            Metadata={"original-filename": file.filename or ""},
        )
        etag = put_resp.get("ETag", "").replace('"', "")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"S3 upload failed: {e}")

    # 7) hash->key
    ddb_put_hash_mapping(h, canonical_key, len(contents), detected_ct)

    # 8) Presigned URL
    presigned_url = None
    try:
        presigned_url = s3.generate_presigned_url(
            "get_object",
            Params={"Bucket": S3_BUCKET, "Key": canonical_key},
            ExpiresIn=3600
        )
    except Exception:
        pass

    return {
        "bucket": S3_BUCKET,
        "key": canonical_key,
        "canonical": True,
        "canonicalKey": canonical_key,
        "duplicate": False,
        "content_type": detected_ct,
        "size": len(contents),
        "etag": etag,
        "presigned_url": presigned_url,
        "moderation": "passed",
    }

# =========================
# Delete endpoint (unchanged)
# =========================
@app.post("/delete-object")
def delete_object(
    key: str = Body(..., embed=True, description="S3 object key, e.g. 'YourWindow/xxx.jpg'"),
    bucket: Optional[str] = Body(None, embed=True, description="Optional bucket; defaults to env S3_BUCKET"),
):
    bkt = (bucket or S3_BUCKET).strip()

    if ALLOWED_DELETE_PREFIXES:
        if not any(key.startswith(p) for p in ALLOWED_DELETE_PREFIXES):
            raise HTTPException(
                status_code=403,
                detail=f"Deletion not allowed for key outside prefixes {ALLOWED_DELETE_PREFIXES}"
            )
    try:
        s3.delete_object(Bucket=bkt, Key=key)
        return {"ok": True, "bucket": bkt, "key": key, "deleted": True}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"S3 delete failed: {e}")

# ===== NEW: direct-to-S3 presign (POST) =====
MAX_DIRECT_S3_UPLOAD = 60 * 1024 * 1024  # 60MB

def _safe_folder(folder: Optional[str], default: str) -> str:
    f = (folder or default).strip().lstrip("/")
    if f and not f.endswith("/"):
        f += "/"
    return f

@app.post("/sign-upload")
def sign_upload(
    folder: Optional[str] = Body("PlantHealth", embed=True),
    content_type: Optional[str] = Body(None, embed=True),
    ext_hint: Optional[str] = Body(None, embed=True),
    content_hash: Optional[str] = Body(None, embed=True),  # <<< NEW
):
    """
    Issue a pre-signed POST so the browser can upload directly to S3.

    If 'content_hash' (SHA-256 hex) is provided, we build a canonical key:
      <folder>/<hash>.<ext>
    and check existence. If exists, return { exists:true } WITHOUT presigned.

    If no/invalid hash, fall back to legacy random key (UUID) for compatibility.
    """
    safe_folder = _safe_folder(folder, "PlantHealth")

    # choose extension
    ext = ".jpg"
    if ext_hint in (".jpg", ".jpeg", ".png"):
        ext = ".png" if ext_hint == ".png" else ".jpg"
    elif content_type == "image/png":
        ext = ".png"

    # ---- canonical path (preferred) ----
    if content_hash and isinstance(content_hash, str) and len(content_hash) == 64 and all(c in "0123456789abcdef" for c in content_hash.lower()):
        h = content_hash.lower()
        key = build_canonical_key(safe_folder, ext, h)

        # check existence via DDB (if configured) or S3 HeadObject
        existing_key = ddb_get_key_by_hash(h) if ddb else (key if s3_object_exists(S3_BUCKET, key) else None)
        if existing_key:
            # Already exists: return exists=true (no presigned)
            return {
                "bucket": S3_BUCKET,
                "key": existing_key,
                "exists": True
            }

        # not exists -> sign a POST locked to this exact key
        conditions = [
            {"bucket": S3_BUCKET},
            ["eq", "$key", key],
            ["content-length-range", 1, MAX_DIRECT_S3_UPLOAD],
        ]
        fields = {"key": key}
        if content_type:
            conditions.append({"Content-Type": content_type})
            fields["Content-Type"] = content_type

        post = s3.generate_presigned_post(
            Bucket=S3_BUCKET,
            Key=key,
            Fields=fields,
            Conditions=conditions,
            ExpiresIn=3600,
        )
        return {
            "bucket": S3_BUCKET,
            "key": key,
            "exists": False,
            "presigned": post,
        }

    # ---- fallback legacy (no hash) ----
    # Keep old behavior: random key under prefix to avoid breaking callers that don't send hash.
    legacy_key = f"{safe_folder}{uuid.uuid4().hex}{ext}"
    conditions = [
        {"bucket": S3_BUCKET},
        ["starts-with", "$key", safe_folder],
        ["content-length-range", 1, MAX_DIRECT_S3_UPLOAD],
    ]
    fields = {}
    if content_type:
        conditions.append({"Content-Type": content_type})
        fields["Content-Type"] = content_type

    post = s3.generate_presigned_post(
        Bucket=S3_BUCKET,
        Key=legacy_key,
        Fields=fields,
        Conditions=conditions,
        ExpiresIn=3600,
    )
    return {
        "bucket": S3_BUCKET,
        "key": legacy_key,
        "exists": False,
        "presigned": post,
    }

# ===== NEW: optional post-upload moderation =====
@app.post("/moderate-object")
def moderate_object(
    key: str = Body(..., embed=True),
    bucket: Optional[str] = Body(None, embed=True),
):
    """
    After a direct-to-S3 upload, run Sightengine on the object.
    If disallowed, delete it and return 400.
    """
    bkt = (bucket or S3_BUCKET).strip()
    try:
        obj = s3.get_object(Bucket=bkt, Key=key)
        data = obj["Body"].read()
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"S3 object not found: {e}")

    # detect type by magic bytes, reuse your helper
    ct = detect_image_type(data)
    if ct not in ALLOWED_CONTENT_TYPES:
        # delete if not valid image
        try: s3.delete_object(Bucket=bkt, Key=key)
        except Exception: pass
        raise HTTPException(status_code=400, detail="Invalid image content")

    # run your existing moderation
    try:
        check_image_with_sightengine(data, key.split("/")[-1], ct)
    except HTTPException as e:
        # if moderation rejects, delete object
        try: s3.delete_object(Bucket=bkt, Key=key)
        except Exception: pass
        raise

    return {"ok": True, "bucket": bkt, "key": key, "moderation": "passed"}

# ============ Lambda entry ============
handler = Mangum(app)
